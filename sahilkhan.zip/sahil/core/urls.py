from atexit import register
from django.contrib import admin
from django.urls import path
from core import views, views1,views2,views3
from core import consumers
from django.urls import path, re_path

urlpatterns = [
	# path('register/', views.registerPage, name="register"),
	# path('login/', views.loginPage, name="login"),  
	# path('logout/', views.logoutUser, name="logout"),


    path("previous/", views.index, name='home1'),
    path("about/", views.about, name='about'),
    path("services/", views.services, name='services'),
    path("services1/", views.services1, name='services1'),
    path("machine/<str:group_name>/", views.machine, name='machine'),
   
    path("header/",views.header, name='header'),
    path("login1/",views.login, name='login1'),
    path("log1/",views.log, name='log1'),
    path('register/',views.register,name="register"),
    path('login_user/',views.login_user,name="login_user"),
    path('services1/logout_user/',views.logout_user,name="logout_user"),
    path('new_machine/',views.new_machine,name="new_machine"),
    path('plot/',views.test,name="plot"),
    path('plot/',views.test,name="plot"),
    path('sensor/',views1.sensor,name="sensor"),
    path('stop/<str:group_name>/',views1.stop,name="stop"),
    path('start/<str:group_name>/',views1.start,name="start"),
    path('delete/<str:group_name>/',views1.delete,name="delete"),
    path("base/",views.base,name="base"),
    path("base1/",views1.newd,name="base1"),
    path("base11/",views1.newd1,name="base11"),
    path("test/",views1.test,name="test"),
    # path("data/<my_id>/",consumers.mname,name="mname"),
    path("emails/",views1.email1,name="email"),
    path("fault/",views1.fault,name="fault"),
    path("fault_P/",views1.fault_P,name="fault_P"),
    path("fault_F/",views1.future_fault,name="fault_F"),
    
    
    
    
    
    path("delete_submit/<str:group_name>/",views1.delete_submit,name="delete_submit"),
    # path("stop_submit/<str:group_name>/",views1.stop_submit,name="stop_submit"),
    path("start_submit/<str:group_name>/",views1.start_submit,name="start_submit"),
    
    path('future_prediction_chart/<str:group_name>/',views1.future_prediction_chart,name="future_prediction_chart"),
    path('future_prediction_chart_hour/<str:group_name>/',views1.future_prediction_chart_hours,name="future_prediction_chart_hour"),
    path('future_prediction_chart_hour_tomorrow/<str:group_name>/',views1.future_prediction_chart_hours_tomorrow,name="future_prediction_chart_hour_tomorrow"),
    path('future_prediction_chart_10/<str:group_name>/',views1.future_prediction_chart_10,name="future_prediction_chart_10"),
    
    path("ai_model/",views1.model_save,name="ai_model"),
    path("ai_time/",views1.model_save_time,name="ai_time"),
    
    path("total_ai/",views1.AImodel,name="total_ai"),
    path("admin_model/",views1.admin_login,name="admin"),
    path("admin_main/",views1.main_admin,name="admin_main"),
    path("admin_main/admin_home/",views1.admin_home,name="admin_home"),
    path("admin_main/all_machine/",views1.all_machine,name="all_machine"),
    path("admin_main/all_user/",views1.all_user,name="all_user"),
    path("admin_main/all_faults/",views1.all_faults,name="all_faults"),
    
    path("user_all_machine/",views1.user_all_machine,name="user_all_machine"),
    
    
    path("KPI/",views1.KPI,name="KPI"),
    
    path("alert/",views1.alert,name="alert"),
    
    path("billing/",views1.billing,name="billing"),
    
    path("",views1.newfront,name="newfront"),
    
    path("admin_main/permission/",views1.permission,name="permission"),
    
    path("admin_main/take/",views1.takepermission,name="take"),
    
    path("admin_main/give/",views1.givepermission,name="give"),
    
    path("admin_main/givenew/",views1.newuserpermission,name="givenew"),
    
    
    path("services1/metrics/",views2.metrics,name="metrics"),
    
    path("guage/",views2.guage,name="guage"),
    
    

    
    
#ARVR
path("AR/temp", views2.temp, name='temp'), 
  
path("AR/noise", views2.noise, name='noise'), 

path("AR/x_vib", views2.x_vib, name='x_vib'),

path("AR/y_vib", views2.y_vib, name='y_vib'), 

path("AR/z_vib", views2.z_vib, name='z_vib'),  

path("AR/press", views2.press, name='press'),  

path("checkpoint/",views2.checkpont,name="check"),

path("level1/",views2.level11,name="level1"),

path("level2/",views2.level22,name="level2"),
  
path("level3/",views2.level33,name="level3"),  

path("level4/",views2.level44,name="level4"),

path("score/<str:group_name>/",views3.Score,name="score"),









    
]
    
