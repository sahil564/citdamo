from django.shortcuts import render
from django.contrib.auth.models import User
from django.http import HttpResponse
from core.views import *
from core.views2 import *



def Score(request,group_name):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    faultp=user.fault_occur_set.all()
    faultm=user.fault_occur_set.filter(email="root@gmail.com")
    all_user=User.objects.all()
    
    print("usermmm",faultm)
    # print("machine",all_user)
    # for i in faultp:
    #     print(i.machine_ID)
    
    print("current user1",user)
    print("all user1",all_user)
    print("which machine contain fault",faultp)     
    print(group_name)
    return render(request,"Mhealth.html",{"groupname":group_name})